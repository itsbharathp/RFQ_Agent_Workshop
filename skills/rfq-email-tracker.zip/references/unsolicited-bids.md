# Unsolicited Bid Handling Reference

## Problem

Vendors may submit bids even when not in the original `RFQInvites` list:
- The RFQ email was forwarded by an invited vendor
- A vendor was CC'd on the original outbound email
- A vendor learned of the RFQ through another channel and replied directly
- The vendor uses a different email address than the one in the vendor master

## Detection

Always perform a broad Outlook search in addition to checking vendor emails from `EmailLog`.
Make both calls in the same turn:

```
search_emails(query="BID {rfq_id}", top=50)
search_emails(query="subject:{rfq_id}", top=50)
```

Filter out:
- Outbound messages from `PROCUREMENT_EMAIL`
- Delivery failure notifications (mailer-daemon, postmaster)
- Forwarded messages from your own account

## Handling Workflow

1. **Classify the email** using the same heuristics as invited vendors
2. **Look up the sender** in the `Vendors` tab by email domain or company name
3. **If found:** use the existing `vendor_id`
4. **If NOT found:** assign a synthetic vendor ID:
   - Format: `EXT-001`, `EXT-002`, etc.
   - Vendor name: use company name from email signature, or "Unknown Vendor (sender@domain.com)"
   - Add a note: "Unsolicited bid — not in original invite list"
5. **Log the bid** to the `Bids` tab with the synthetic ID
6. **Log the email** to the `EmailLog` tab for audit trail
7. **Alert procurement team** in chat with a clear flag that this is an unsolicited bid

## Example Bid Log Entry

| bid_id | rfq_id | vendor_id | vendor_name | bid_date | bid_total_usd | delivery_days | notes |
|--------|--------|-----------|-------------|----------|---------------|---------------|-------|
| BID-RFQ-0203-EXT | RFQ-0203 | EXT-001 | Edge Components (Jayanth Bagare) | 2026-05-25 | 375000 | 17 | Unsolicited bid — not in original invite list |

## Evaluation Decision

The procurement team must explicitly decide whether to include unsolicited bids:
- Include them in bid count for trigger purposes
- Flag them distinctly in the status summary
- Do NOT auto-trigger evaluation solely based on unsolicited bids unless the team has a policy to include them
