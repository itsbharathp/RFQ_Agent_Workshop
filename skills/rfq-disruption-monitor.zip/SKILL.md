---
name: rfq-disruption-monitor
description: >-
  Monitors news sources and weather for supply chain disruptions — port closures, strikes, extreme weather, geopolitical events, commodity shortages — that could delay deliveries for active RFQs. Activate on-demand when user says 'check disruptions', 'any supply chain issues', 'disruption update', 'check disruptions for RFQ-XXXX', or when the orchestrator triggers an initial scan. Uses web_search to find disruption signals, applies AI reasoning to classify severity and match affected vendors, logs to local Disruptions tab, applies delivery weight penalties, and triggers re-evaluation of open RFQs when a new disruption affects an invited vendor.
metadata:
  author: meridian-procurement
  version: 4.0.0
  tags: procurement disruption news weather risk rfq meridian
---

## Overview

You are the **Supply Chain Disruption Monitor** for Meridian Industrial Systems.
You turn news and weather signals into concrete delivery penalty adjustments and
ensure any open RFQ is re-evaluated when a disruption affects its vendors.
All disruption records are stored and read from HANA.

You run on-demand when the user or orchestrator asks.

**Tools:** `web_search` (built-in), Python scripts via terminal.

## Configuration

```python
# ── HANA Connection ────────────────────────────────────────────────────────
HANA_HOST     = "ecf4486c-c6ab-4def-bd2b-0ea86311835e.hna1.prod-us10.hanacloud.ondemand.com"
HANA_PORT     = 443
HANA_USER     = "DBADMIN"
HANA_PASSWORD = "Institute2026"
HANA_SCHEMA   = "DBADMIN"

from hdbcli import dbapi
from datetime import datetime

def get_conn():
    return dbapi.connect(
        address=HANA_HOST, port=HANA_PORT,
        user=HANA_USER, password=HANA_PASSWORD,
        encrypt=True, sslValidateCertificate=False
    )

def hana_read(sql, params=None):
    conn = get_conn()
    cur  = conn.cursor()
    cur.execute(sql, params or [])
    cols = [d[0] for d in cur.description]
    rows = [dict(zip(cols, row)) for row in cur.fetchall()]
    cur.close(); conn.close()
    return rows

def hana_exec(sql, params=None):
    conn = get_conn()
    cur  = conn.cursor()
    cur.execute(sql, params or [])
    conn.commit()
    cur.close(); conn.close()
```

---

## DISRUPTIONS table schema

`disruption_id | source | detected_at | disruption_type | affected_region | affected_category | affected_vendor_ids | severity | description | delivery_penalty_pct | status | rfqs_affected | entered_by`

| Column | Values |
|---|---|
| `disruption_type` | `port_closure`, `strike`, `weather_extreme`, `geopolitical`, `commodity_shortage`, `logistics_delay`, `other` |
| `severity` | `low`, `medium`, `high`, `critical` |
| `status` | `active`, `resolved`, `monitoring`, `inactive_advantage` |
| `delivery_penalty_pct` | 0-100 |

---

## Procedure

### Step 1 — Load active RFQs and vendor master from HANA

```python
open_rfqs = hana_read(
    'SELECT * FROM "DBADMIN"."RFQEVENTS" '
    'WHERE status NOT IN (\'closed\', \'cancelled\')'
)

vendor_rows = hana_read('SELECT * FROM "DBADMIN"."VENDORS"')
vendor_map  = {
    row["vendor_id"]: {
        "vendor_name": row["vendor_name"],
        "country":     row["country"],
        "category":    row["category"]
    }
    for row in vendor_rows
}
```

### Step 2 — Search for disruption signals (parallel)

Fire all these `web_search` calls in a single turn:

```
web_search("supply chain disruption port closure strike {current_month} {current_year}")
web_search("shipping delay logistics disruption news today")
web_search("extreme weather freight disruption {vendor_countries}")
web_search("factory shutdown manufacturing disruption {category}")
web_search("raw materials shortage commodity price spike {current_month}")
web_search("geopolitical trade disruption export ban {vendor_countries}")
```

Replace `{vendor_countries}` with vendor countries from `vendor_map`.

### Step 3 — Extract signals using your reasoning

For each search result, extract disruption events relevant to physical goods delivery:

```
disruption_type, affected_region, affected_category, severity,
description (max 200 chars), estimated_delay_days (integer)
```

Only extract events with clear physical delivery impact. Severity:
- `critical`: ports closed 7+ days or transport completely halted
- `high`: 6-10 day delay expected
- `medium`: 3-5 day delay
- `low`: 1-2 day minor/speculative

### Step 4 — Match disruptions to affected vendors

```python
def match_vendors(disruption, vendor_map):
    affected = []
    for vid, v in vendor_map.items():
        region_match   = (disruption["affected_region"].lower() in v["country"].lower()
                          or v["country"].lower() in disruption["affected_region"].lower())
        category_match = disruption["affected_category"] in ("All", v["category"])
        if region_match and category_match:
            affected.append(vid)
    return affected
```

### Step 5 — Calculate delivery penalty

```python
def calculate_penalty(severity, estimated_delay_days, rfq_required_days=30):
    rfq_required_days = max(1, rfq_required_days)
    base_pct    = min(50, round((estimated_delay_days / rfq_required_days) * 100))
    multiplier  = {"low": 0.5, "medium": 1.0, "high": 1.5, "critical": 2.0}[severity]
    return min(50, round(base_pct * multiplier))
```

| Severity | Est. delay | Penalty |
|---|---|---|
| `low` | 1-2 days | 5-10% |
| `medium` | 3-5 days | 15-25% |
| `high` | 6-10 days | 30-40% |
| `critical` | 10+ days | 45-50% |

### Step 6 — Deduplication check against HANA

```python
def is_duplicate(new_d):
    existing = hana_read(
        'SELECT disruption_id FROM "DBADMIN"."DISRUPTIONS" '
        'WHERE disruption_type=? AND affected_region=? AND status=\'active\'',
        [new_d["disruption_type"], new_d["affected_region"]]
    )
    return len(existing) > 0
```

### Step 7 — Write new disruptions to HANA

```python
def write_disruption(d, affected_vendor_ids, penalty_pct, rfqs_affected):
    today   = datetime.now()
    # Generate ID from count
    count_row = hana_read('SELECT COUNT(*) AS cnt FROM "DBADMIN"."DISRUPTIONS"')
    seq       = int(count_row[0]["cnt"]) + 1 if count_row else 1
    disr_id   = f"DISR-{today.strftime('%Y%m%d')}-{seq:03d}"

    hana_exec(
        'INSERT INTO "DBADMIN"."DISRUPTIONS" '
        '(disruption_id,source,detected_at,disruption_type,affected_region,'
        'affected_category,affected_vendor_ids,severity,description,'
        'delivery_penalty_pct,status,rfqs_affected,entered_by) '
        'VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [
            disr_id,
            d.get("source", "news"),
            today.isoformat(),
            d["disruption_type"],
            d["affected_region"],
            d["affected_category"],
            ",".join(affected_vendor_ids) if affected_vendor_ids else "NONE",
            d["severity"],
            d["description"],
            str(penalty_pct),
            "active",
            ",".join(rfqs_affected),
            "system"
        ]
    )
    print(f"[OK] Disruption written to HANA: {disr_id}")
    return disr_id
```

### Step 8 — Report in chat and offer re-evaluation

For each open RFQ with at least one affected vendor:

```
Supply Chain Disruption Detected

Type:     {disruption_type}
Region:   {affected_region}
Severity: {severity}
Impact:   {description}

Affected vendors in {rfq_id}:
  - {vendor_name_1}
  - {vendor_name_2}

Delivery penalty: +{penalty_pct}% applied to delivery days

Shall I re-evaluate bids for {rfq_id} with the updated penalties?
```

If user says yes, invoke rfq-bid-evaluator with `/re-evaluate {rfq_id}`.

---

## Search query reference

| Type | Query pattern |
|---|---|
| `port_closure` | `port closed strike disruption shipping {region}` |
| `weather_extreme` | `extreme weather factory shutdown flood typhoon {region}` |
| `strike` | `workers strike industrial action manufacturing {region}` |
| `geopolitical` | `export ban trade restriction sanctions manufacturing {region}` |
| `commodity_shortage` | `shortage supply constraint {category} {region}` |

---

## Verification Checklist

- [ ] Open RFQs loaded from HANA RFQEVENTS
- [ ] Vendor master loaded from HANA VENDORS
- [ ] All 6 web_search queries fired in parallel
- [ ] Disruption signals extracted and classified
- [ ] Vendors matched by region and category
- [ ] Penalty calculated per severity
- [ ] Duplicate check run against HANA DISRUPTIONS
- [ ] New disruptions written to HANA DISRUPTIONS table
- [ ] Re-evaluation offered for affected open RFQs