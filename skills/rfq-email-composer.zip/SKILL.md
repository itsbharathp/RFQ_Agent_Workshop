---
name: rfq-email-composer
description: >-
  Drafts personalised RFQ emails to each invited vendor and saves them as .txt files in Output/Emails/ for the user to send from their Outlook client. Activate when the orchestrator delegates Phase 2, or when user says 'draft RFQ emails', 'compose RFQ for vendors', 'prepare RFQ emails'. Creates one draft file per vendor with TO, SUBJECT, BODY and ATTACHMENT details. Personalises tone by vendor archetype. Logs drafts to EmailLog tab. Updates status to sent once user confirms. Also creates RFQ specification document in Output/ and reminds user of non-responder follow-up date.
metadata:
  version: 4.0.0
---

## Overview

You are the **RFQ Email Composer** for Meridian Industrial Systems. You write
genuinely good procurement emails — specific, professional, and personalised to
each vendor's archetype. You draft emails as `.txt` files in `Output/Emails/`
for the user to send from their Outlook client. All logging is done to HANA.

## When to Use

- Orchestrator delegates Phase 2 (RFQ email drafting)
- User says: "draft RFQ emails", "compose RFQ for vendors", "prepare RFQ emails"

## Configuration

```python
# ── HANA Connection ────────────────────────────────────────────────────────
HANA_HOST     = "ecf4486c-c6ab-4def-bd2b-0ea86311835e.hna1.prod-us10.hanacloud.ondemand.com"
HANA_PORT     = 443
HANA_USER     = "DBADMIN"
HANA_PASSWORD = "Institute2026"
HANA_SCHEMA   = "DBADMIN"
PROCUREMENT_EMAIL = "bharath.prasad@sap.com"
OUTPUT_DIR    = "/Users/I031973/Documents/Joule_Desktop/RFQ_Agent_Joule/Output"
EMAILS_DIR    = f"{OUTPUT_DIR}/Emails"

import os
from datetime import datetime
from hdbcli import dbapi

def get_conn():
    return dbapi.connect(
        address=HANA_HOST, port=HANA_PORT,
        user=HANA_USER, password=HANA_PASSWORD,
        encrypt=True, sslValidateCertificate=False
    )

def hana_read(sql, params=None):
    conn = get_conn()
    cur  = conn.cursor()
    cur.execute(sql, params or [])
    cols = [d[0] for d in cur.description]
    rows = [dict(zip(cols, row)) for row in cur.fetchall()]
    cur.close(); conn.close()
    return rows

def hana_exec(sql, params=None):
    conn = get_conn()
    cur  = conn.cursor()
    cur.execute(sql, params or [])
    conn.commit()
    cur.close(); conn.close()

os.makedirs(EMAILS_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)
```

## Inputs expected

```
rfq_id:           RFQ-0042
work_order_id:    WO-2024-0042
invited_vendors:  [{vendor_id, vendor_name, contact_email, contact_name,
                    behavioral_archetype, relationship_years, score}]
rfq_deadline:     2024-09-05
category:         Mechanical Parts
items:            [{description, quantity, unit, target_unit_price_usd, required_by_date}]
urgency:          standard | expedited | critical
```

---

## Procedure

### Step 1 — Create the RFQ specification document

```python
spec_path = f"{OUTPUT_DIR}/RFQ-Spec-{rfq_id}.txt"
if not os.path.exists(spec_path):
    item_rows = "\n".join(
        f"| {i+1} | {item['description']} | {item['quantity']} | {item['unit']} "
        f"| ${item.get('target_unit_price_usd','TBD')} | {item.get('required_by_date','see WO')} |"
        for i, item in enumerate(items)
    )
    spec_content = f"""# RFQ Specification -- {rfq_id}

Work Order   : {work_order_id}
Category     : {category}
Bid Deadline : {rfq_deadline}
Contact      : {PROCUREMENT_EMAIL}

## Items Required

| # | Description | Qty | Unit | Target Unit Price (USD) | Required By |
|---|---|---|---|---|---|
{item_rows}

## Terms and Conditions

- Prices must be quoted in USD, CIF Meridian Industrial Systems, Bangalore.
- Bids valid for minimum 30 days from submission date.
- Include lead time in calendar days from PO date.
- Attach product datasheets and quality certificates with your bid.
- Meridian reserves the right to award to multiple vendors or reject all bids.

## Submission Instructions

Reply to this email with your quotation.
Subject line must include: BID - {rfq_id}
"""
    with open(spec_path, "w", encoding="utf-8") as f:
        f.write(spec_content)
```

### Step 2 — Confirm recipient addresses with user

Before drafting, ask:
> "Shall I use the vendor contact emails on file, or override with a different
> address (e.g. for testing or a shared procurement inbox)?"

### Step 3 — Draft personalised email per vendor

| Archetype | Tone | Emphasise |
|---|---|---|
| `reliable` | Warm, collegial | Long relationship, confidence in quality |
| `conservative` | Formal, structured | Clear specs, no surprises, solid terms |
| `aggressive_bidder` | Direct, competitive | Volume potential, fast payment, repeat business |
| `relationship_focused` | Personal, appreciative | Partnership, mutual growth, past work reference |
| `volatile` | Neutral, deadline-firm | Clear deadline, consequences of missing it |

```python
TEMPLATES = {
    "reliable": """Dear {contact_first_name},

I hope this finds you well. Following our continued strong partnership -- {relationship_years} years and counting -- I am pleased to share RFQ {rfq_id} for {category} components.

Given your track record with us, you are among a select group of vendors we are approaching first. The specification is attached; please review and revert by {rfq_deadline}.

We look forward to another successful engagement.""",

    "aggressive_bidder": """Dear {contact_first_name},

Meridian Industrial Systems is inviting competitive bids for RFQ {rfq_id} ({category}). We are seeking best-in-class pricing and have a clear budget target in mind.

This order has potential for repeat volume quarterly. Vendors offering the most competitive unit pricing with reliable delivery will be prioritised for framework agreements.

Bid deadline: {rfq_deadline}. Reply with BID - {rfq_id} in your subject line.""",

    "conservative": """Dear {contact_first_name},

Please find enclosed RFQ {rfq_id} for {n_items} line items in the {category} category. Full specifications, quantities, and terms are detailed in the attached document.

Bids must be submitted by {rfq_deadline} and should include: unit prices in USD, lead time in calendar days, quality certificates, and 30-day validity confirmation.

For any technical clarifications, please respond to this email.""",

    "volatile": """Dear {contact_first_name},

Meridian is issuing RFQ {rfq_id} for {category} with a firm bid deadline of {rfq_deadline}.
Late submissions cannot be considered for this procurement cycle.

Please confirm receipt of this RFQ within 24 hours and submit your complete quotation before the deadline.""",

    "relationship_focused": """Dear {contact_first_name},

It is always a pleasure to work with your team. We are reaching out to {vendor_name} for RFQ {rfq_id} -- {category} components for an important customer delivery.

We value the trust and quality you have consistently delivered. I would appreciate your competitive quotation by {rfq_deadline}. As always, feel free to call me directly if you need to discuss any line item.""",
}

def render_email(vendor, template_str, rfq_id, rfq_deadline, n_items, category):
    body = template_str.format(
        contact_first_name=vendor["contact_name"].split()[0],
        vendor_name=vendor["vendor_name"],
        relationship_years=vendor.get("relationship_years", "several"),
        rfq_id=rfq_id, rfq_deadline=rfq_deadline,
        n_items=n_items, category=category,
    )
    return body + f"\n\nPlease find the RFQ specification attached.\n\nBest regards,\nMeena Krishnan\nProcurement Manager, Meridian Industrial Systems\n{PROCUREMENT_EMAIL}"

def build_subject(urgency, rfq_id, category):
    base = f"Request for Quotation \u2014 {rfq_id} \u2014 {category}"
    if urgency == "critical":   return f"URGENT: {base}"
    if urgency == "expedited":  return f"EXPEDITED: {base}"
    return base
```

### Step 4 — Save email drafts to Output/Emails/

```python
for vendor in invited_vendors:
    archetype  = vendor.get("behavioral_archetype", "conservative")
    template   = TEMPLATES.get(archetype, TEMPLATES["conservative"])
    body       = render_email(vendor, template, rfq_id, rfq_deadline, len(items), category)
    subject    = build_subject(urgency, rfq_id, category)
    recipient  = override_email or vendor["contact_email"]

    draft_path = f"{EMAILS_DIR}/RFQ-{rfq_id}-{vendor['vendor_id']}.txt"
    with open(draft_path, "w", encoding="utf-8") as f:
        f.write(f"TO: {recipient}\n")
        f.write(f"SUBJECT: {subject}\n")
        f.write(f"ATTACHMENT: {spec_path}\n")
        f.write("---\n")
        f.write(body)
```

### Step 5 — Log drafts to HANA EMAILLOG

```python
for vendor in invited_vendors:
    recipient = override_email or vendor["contact_email"]
    hana_exec(
        'INSERT INTO "DBADMIN"."EMAILLOG" '
        '(rfq_id,vendor_id,drafted_at,vendor_email,outlook_message_id,status,deadline) '
        'VALUES (?,?,?,?,?,?,?)',
        [
            rfq_id, vendor["vendor_id"],
            datetime.now().isoformat(),
            recipient, "", "drafted", rfq_deadline
        ]
    )
print(f"[OK] EmailLog updated in HANA for {len(invited_vendors)} vendors")
```

Schema: `rfq_id | vendor_id | drafted_at | vendor_email | outlook_message_id | status | deadline`

### Step 6 — Present drafts summary and send instructions

```
RFQ email drafts ready -- {n} vendors

Vendor                     Recipient                    Draft file
Strömberg Hydraulics AB    sandra@stromberghydra.com    Output/Emails/RFQ-{rfq_id}-V004.txt
...

RFQ spec: Output/RFQ-Spec-{rfq_id}.txt

To send from Outlook:
1. Open each draft from Output/Emails/
2. Compose new email: paste TO, SUBJECT, BODY
3. Attach: Output/RFQ-Spec-{rfq_id}.txt
4. Send all emails

Once sent, say "emails sent for {rfq_id}" to update the log.
```

### Step 7 — Update log on user send confirmation

```python
hana_exec(
    'UPDATE "DBADMIN"."EMAILLOG" SET status=? '
    'WHERE rfq_id=? AND status=?',
    ["sent", rfq_id, "drafted"]
)
print(f"[OK] EMAILLOG updated to 'sent' for all {rfq_id} drafts")
```

### Step 8 — Non-responder follow-up reminder

Compute reminder date as `rfq_deadline - 2 days` and tell the user:

```
Reminder: {n} vendors sent RFQ {rfq_id}.
Deadline: {rfq_deadline}.

Add to your calendar for {reminder_date}:
"Chase non-responders for RFQ {rfq_id} -- check Outlook for replies."
```

---

## Tone rules

- Never "Dear Sir/Madam" — always use the contact's first name.
- Never send identical body to two vendors.
- If urgency is critical, the deadline must appear in the first sentence.
- Always include the spec file path in the draft header.

## Verification Checklist

- [ ] RFQ spec doc created in Output/
- [ ] Recipient override confirmed with user
- [ ] Email template selected per vendor archetype
- [ ] Each email personalised with contact name and relationship context
- [ ] URGENT: / EXPEDITED: subject prefix applied for critical/expedited
- [ ] All draft files saved to Output/Emails/
- [ ] HANA EMAILLOG updated with drafted status and vendor emails
- [ ] Draft summary shown with send instructions
- [ ] User confirmed emails sent; HANA EMAILLOG updated to sent
- [ ] Non-responder follow-up date provided to user for calendar