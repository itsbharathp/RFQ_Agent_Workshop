---
name: rfq-bid-evaluator
description: >-
  Scores and ranks all received bids for an RFQ using a weighted multi-criteria model with live supply chain disruption penalties. Activate when the orchestrator triggers Phase 4, when the tracker fires '/evaluate {rfq_id}', when the disruption monitor fires '/re-evaluate {rfq_id}', or when user says 'evaluate bids', 'score the bids for RFQ', 'who has the best bid', 're-evaluate with disruptions'. Reads bids from local Excel bid log, loads active disruption penalties from Disruptions tab, applies them to delivery scores, writes ranked evaluation back to BidEvaluation tab, and reports results in chat. Always checks for active disruptions even on first evaluation.
metadata:
  author: meridian-procurement
  version: 4.0.0
  tags: procurement evaluation scoring bids rfq disruption meridian
---

## Overview

You are the **Bid Evaluator** for Meridian Industrial Systems. You apply a
transparent, repeatable scoring model to all received bids. Before scoring,
you always check the HANA DISRUPTIONS table for active supply chain signals
and apply delivery penalties automatically.

When called with `/re-evaluate {rfq_id}`, you re-run evaluation with fresh
disruption data and report updated rankings showing what changed.

## When to Use

- Orchestrator triggers Phase 4 (bid evaluation)
- Tracker reports threshold met and user confirms evaluation
- Disruption monitor fires `/re-evaluate {rfq_id}`
- User says: "evaluate bids", "score bids", "rank vendors", "re-evaluate because of [disruption]"

## Configuration

```python
# ── HANA Connection ────────────────────────────────────────────────────────
HANA_HOST     = "ecf4486c-c6ab-4def-bd2b-0ea86311835e.hna1.prod-us10.hanacloud.ondemand.com"
HANA_PORT     = 443
HANA_USER     = "DBADMIN"
HANA_PASSWORD = "Institute2026"
HANA_SCHEMA   = "DBADMIN"
PROCUREMENT_EMAIL = "bharath.prasad@sap.com"

from hdbcli import dbapi
from datetime import datetime

def get_conn():
    return dbapi.connect(
        address=HANA_HOST, port=HANA_PORT,
        user=HANA_USER, password=HANA_PASSWORD,
        encrypt=True, sslValidateCertificate=False
    )

def hana_read(sql, params=None):
    conn = get_conn()
    cur  = conn.cursor()
    cur.execute(sql, params or [])
    cols = [d[0] for d in cur.description]
    rows = [dict(zip(cols, row)) for row in cur.fetchall()]
    cur.close(); conn.close()
    return rows

def hana_exec(sql, params=None):
    conn = get_conn()
    cur  = conn.cursor()
    cur.execute(sql, params or [])
    conn.commit()
    cur.close(); conn.close()
```

---

## Scoring model

**Standard weights** (sum to 100):

| Criterion | Weight | Notes |
|---|---|---|
| Price | 50 | Relative to lowest bid received |
| Delivery speed | 30 | Relative to required_by_date, after disruption penalty |
| Payment terms | 20 | Favourable terms = better cash flow |

**Urgency adjustment** (critical orders):

| Criterion | Weight |
|---|---|
| Price | 35 |
| Delivery speed | 45 |
| Payment terms | 20 |

**Payment terms scoring:**

| Terms | Score (0-10) |
|---|---|
| Net 30 | 10 |
| 2/10 Net 30 | 9 |
| Net 45 | 7 |
| Net 60 | 5 |
| LC at sight | 3 |
| LC 30/60/90 | 1 |

---

## Disruption penalty model

```
effective_delivery_days = bid_delivery_days * (1 + delivery_penalty_pct / 100)
```

A vendor with 22-day lead time and 30% penalty is scored as if they quoted 28.6 days.
The actual bid is unchanged — only the score reflects the risk.

---

## Procedure

### Step 1 — Load bids for this RFQ from HANA

```python
bids = hana_read(
    'SELECT * FROM "DBADMIN"."BIDS" WHERE rfq_id=? AND status=\'received\'',
    [rfq_id]
)
if not bids:
    print(f"No bids found for RFQ {rfq_id}. Cannot evaluate.")
    # Stop here
```

### Step 2 — Load vendor master from HANA

```python
vendor_rows  = hana_read('SELECT * FROM "DBADMIN"."VENDORS"')
vendor_master = {row["vendor_id"]: row for row in vendor_rows}
```

### Step 3 — Load active disruption penalties from HANA

**Always run this step — even on a first evaluation.**

```python
def load_disruption_penalties(rfq_id, bids):
    active_disrs = hana_read(
        'SELECT * FROM "DBADMIN"."DISRUPTIONS" WHERE status=\'active\''
    )
    bid_vids = {b["vendor_id"] for b in bids}
    penalties = {}
    for d in active_disrs:
        raw_ids      = str(d.get("affected_vendor_ids") or "")
        affected_ids = set(v.strip() for v in raw_ids.split(","))
        for vid in bid_vids:
            if vid in affected_ids or raw_ids == "ALL_IN_REGION":
                existing = penalties.get(vid, {}).get("penalty_pct", 0)
                new_p    = float(d.get("delivery_penalty_pct") or 0)
                stacked  = min(50, existing + new_p)
                penalties[vid] = {
                    "penalty_pct":     stacked,
                    "reason":          d.get("description", ""),
                    "severity":        d.get("severity", ""),
                    "disruption_id":   d.get("disruption_id", ""),
                    "disruption_type": d.get("disruption_type", ""),
                }
    return penalties

disruption_penalties = load_disruption_penalties(rfq_id, bids)

if disruption_penalties:
    bids_by_vendor = {b["vendor_id"]: b for b in bids}
    affected_names = [
        f"{bids_by_vendor[v]['vendor_name']} (+{p['penalty_pct']}%)"
        for v, p in disruption_penalties.items() if v in bids_by_vendor
    ]
    print(
        f"Active disruptions found for {len(disruption_penalties)} vendor(s):\n"
        + "\n".join(f"  - {n}" for n in affected_names)
        + "\nApplying delivery penalties to scores..."
    )
```

### Step 4 — Score all bids with disruption-adjusted delivery

```python
def score_bids(bids, vendor_master, disruption_penalties, weights, required_by_date, rfq_id):
    min_bid        = min(float(b["bid_total_usd"]) for b in bids)
    target_dt      = datetime.fromisoformat(required_by_date)
    available_days = max(1, (target_dt - datetime.now()).days)
    payment_map    = {
        "Net 30": 10, "2/10 Net 30": 9, "Net 45": 7,
        "Net 60": 5, "LC at sight": 3, "LC 30": 2, "LC 60": 1, "LC 90": 1
    }
    scored = []
    for bid in bids:
        vid        = bid["vendor_id"]
        v          = vendor_master.get(vid, {})
        bid_total  = float(bid["bid_total_usd"])
        price_score    = weights["price"] * (min_bid / bid_total) if bid_total > 0 else 0
        base_days      = float(bid.get("delivery_days") or 30)
        penalty        = disruption_penalties.get(vid, {})
        penalty_pct    = float(penalty.get("penalty_pct", 0))
        effective_days = base_days * (1 + penalty_pct / 100)
        if effective_days <= available_days:
            buffer         = available_days - effective_days
            delivery_score = weights["delivery"] * min(1.0, 0.7 + 0.3 * (buffer / available_days))
        else:
            lateness       = effective_days / available_days
            delivery_score = weights["delivery"] * max(0, 1 - (lateness - 1))
        pay_raw        = payment_map.get(str(bid.get("payment_terms","Net 30")).strip(), 5)
        pay_score      = weights["payment"] * (pay_raw / 10)
        archetype      = v.get("behavioral_archetype", "unknown")
        archetype_note = ""
        if archetype == "volatile":
            archetype_note = "Volatile archetype — monitor post-award"
        elif archetype == "aggressive_bidder" and price_score > weights["price"] * 0.9:
            archetype_note = "Aggressive bidder — verify capacity"
        disruption_note = ""
        if penalty:
            disruption_note = (
                f"{penalty['disruption_type'].replace('_',' ').title()} "
                f"({penalty['severity'].upper()}) — "
                f"+{penalty_pct:.0f}% delivery penalty. {penalty['reason']}"
            )
        composite = round(price_score + delivery_score + pay_score, 2)
        scored.append({
            "rfq_id": rfq_id, "vendor_id": vid,
            "vendor_name": bid["vendor_name"],
            "bid_total_usd": bid_total, "delivery_days": base_days,
            "effective_delivery_days": round(effective_days, 1),
            "payment_terms": bid.get("payment_terms", "Net 30"),
            "price_score": round(price_score, 2),
            "delivery_score": round(delivery_score, 2),
            "pay_score": round(pay_score, 2),
            "composite_score": composite,
            "disruption_penalty_pct": penalty_pct,
            "disruption_note": disruption