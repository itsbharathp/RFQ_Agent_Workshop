# RFQ Summary Report Generation

This reference covers generating the RFQ closure report as HTML and PDF.
Both files are saved to `Output/` under the base path.

---

## Dependencies

```bash
pip install weasyprint
```

---

## Step R1 — Build the HTML report

```python
from datetime import datetime

def build_html_report(rfq_id, work_order_id, category, rfq_issue_date,
                      shortlist, dropped, weights, budget_ceiling,
                      delivery_followup_date, bid_log_path):

    today_str = datetime.now().strftime("%d %B %Y")

    def score_bar(score, max_score=100):
        pct   = min(100, round(score / max_score * 100))
        color = "#1a7a4a" if pct >= 70 else "#d97706" if pct >= 50 else "#dc2626"
        return f'<div class="score-bar-wrap"><div class="score-bar" style="width:{pct}%;background:{color};"></div><span class="score-label">{score:.1f}</span></div>'

    shortlist_rows = ""
    for i, b in enumerate(shortlist):
        medal = ["&#127947;", "&#129352;", "&#129353;", "4th", "5th"][i]
        note  = f'<div class="archetype-note">{b["archetype_note"]}</div>' if b.get("archetype_note") else ""
        shortlist_rows += f"""
        <tr class="{'selected-row' if i < 3 else 'selected-row-alt'}">
          <td class="rank">{medal}</td>
          <td><strong>{b['vendor_name']}</strong>{note}</td>
          <td class="money">${float(b['bid_total_usd']):,.0f}</td>
          <td class="center">{b['delivery_days']} days</td>
          <td class="center">{b.get('payment_terms','&mdash;')}</td>
          <td>{score_bar(float(b['composite_score']))}</td>
          <td class="justification">{b['justification']}</td>
        </tr>"""

    dropped_rows = ""
    for b in dropped:
        dropped_rows += f"""
        <tr>
          <td>{b['vendor_name']}</td>
          <td class="money">${float(b['bid_total_usd']):,.0f}</td>
          <td class="center">{b['delivery_days']} days</td>
          <td class="center">{float(b['composite_score']):.1f}</td>
          <td>{b['drop_reason']}</td>
        </tr>"""

    weight_rows = "".join(
        f"<tr><td>{k.title()}</td><td class='center'>{v}%</td></tr>"
        for k, v in weights.items()
    )

    splits = [("Primary (Rank #1)", "40%"), ("Secondary (Rank #2)", "30%")]
    for i in range(2, min(5, len(shortlist))):
        splits.append((f"Rank #{i+1} &mdash; active alternate", "10%"))
    split_rows = "".join(
        f"<tr><td>{label}</td><td>{pct}</td><td>{shortlist[j]['vendor_name']}</td></tr>"
        for j, (label, pct) in enumerate(splits)
    )

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>RFQ Summary &mdash; {rfq_id}</title>
<style>
  *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #1a1a2e; background: #f4f6f9; }}
  .page {{ max-width: 960px; margin: 0 auto; background: #fff; box-shadow: 0 2px 16px rgba(0,0,0,0.10); }}
  .header {{ background: linear-gradient(135deg, #1F4E79 0%, #2E75B6 100%); color: #fff; padding: 28px 36px 24px; }}
  .header-top {{ display: flex; justify-content: space-between; align-items: flex-start; }}
  .company {{ font-size: 11px; letter-spacing: 1.5px; opacity: 0.8; text-transform: uppercase; margin-bottom: 6px; }}
  .doc-title {{ font-size: 22px; font-weight: bold; margin-bottom: 4px; }}
  .rfq-badge {{ background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.4); border-radius: 6px; padding: 8px 16px; text-align: right; font-size: 11px; }}
  .rfq-badge .rfq-id {{ font-size: 18px; font-weight: bold; }}
  .status-badge {{ display: inline-block; background: #22c55e; color: #fff; font-size: 10px; font-weight: bold; padding: 3px 10px; border-radius: 20px; letter-spacing: 1px; text-transform: uppercase; margin-top: 6px; }}
  .meta-strip {{ background: #EBF3FB; border-bottom: 2px solid #2E75B6; padding: 14px 36px; display: flex; gap: 32px; flex-wrap: wrap; }}
  .meta-item {{ display: flex; flex-direction: column; }}
  .meta-label {{ font-size: 10px; color: #5a7a9a; text-transform: uppercase; letter-spacing: 0.8px; font-weight: bold; }}
  .meta-value {{ font-size: 13px; font-weight: 600; color: #1F4E79; margin-top: 2px; }}
  .section {{ padding: 24px 36px; border-bottom: 1px solid #e8edf2; }}
  .section-title {{ font-size: 13px; font-weight: bold; color: #1F4E79; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 14px; padding-bottom: 6px; border-bottom: 2px solid #D6E4F0; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 12px; }}
  th {{ background: #1F4E79; color: #fff; padding: 9px 10px; text-align: left; font-size: 11px; font-weight: bold; }}
  td {{ padding: 9px 10px; border-bottom: 1px solid #e8edf2; vertical-align: middle; }}
  .selected-row {{ background: #f0faf4; }}
  .selected-row-alt {{ background: #f7fbff; }}
  .rank {{ font-size: 16px; text-align: center; width: 42px; }}
  .money {{ font-weight: 600; text-align: right; }}
  .center {{ text-align: center; }}
  .justification {{ font-size: 11px; color: #4a6080; max-width: 220px; }}
  .score-bar-wrap {{ display: flex; align-items: center; gap: 8px; min-width: 100px; }}
  .score-bar {{ height: 8px; border-radius: 4px; flex: 1; max-width: 80px; }}
  .score-label {{ font-weight: bold; font-size: 12px; }}
  .archetype-note {{ font-size: 10px; color: #d97706; margin-top: 3px; background: #fffbeb; border-left: 2px solid #d97706; padding: 2px 6px; }}
  .weights-table {{ max-width: 320px; }}
  .rec-box {{ background: #f0faf4; border: 1px solid #86efac; border-left: 4px solid #22c55e; border-radius: 6px; padding: 14px 18px; margin-bottom: 16px; font-size: 12px; color: #1a4731; }}
  .checklist {{ list-style: none; padding: 0; }}
  .checklist li {{ padding: 6px 0 6px 28px; position: relative; border-bottom: 1px solid #f0f0f0; font-size: 12px; }}
  .checklist li::before {{ content: "\u2610"; position: absolute; left: 4px; color: #2E75B6; font-size: 14px; }}
  .footer {{ background: #1F4E79; color: rgba(255,255,255,0.7); padding: 14px 36px; font-size: 10px; display: flex; justify-content: space-between; align-items: center; }}
  @media print {{ body {{ background: #fff; }} .page {{ box-shadow: none; }} tr {{ page-break-inside: avoid; }} }}
  @page {{ margin: 15mm 15mm 20mm; }}
</style>
</head>
<body>
<div class="page">
  <div class="header">
    <div class="header-top">
      <div>
        <div class="company">Meridian Industrial Systems</div>
        <div class="doc-title">RFQ Closure Summary</div>
        <div style="font-size:12px;opacity:0.85;margin-top:4px;">Prepared by Joule Work Desktop &mdash; Procurement Agent &middot; {today_str}</div>
      </div>
      <div class="rfq-badge">
        <div style="opacity:0.8;font-size:10px;">RFQ Reference</div>
        <div class="rfq-id">{rfq_id}</div>
        <div class="status-badge">&#10003; Closed</div>
      </div>
    </div>
  </div>
  <div class="meta-strip">
    <div class="meta-item"><span class="meta-label">Work Order</span><span class="meta-value">{work_order_id}</span></div>
    <div class="meta-item"><span class="meta-label">Category</span><span class="meta-value">{category}</span></div>
    <div class="meta-item"><span class="meta-label">Issued</span><span class="meta-value">{rfq_issue_date}</span></div>
    <div class="meta-item"><span class="meta-label">Closed</span><span class="meta-value">{today_str}</span></div>
    <div class="meta-item"><span class="meta-label">Bids Evaluated</span><span class="meta-value">{len(shortlist) + len(dropped)}</span></div>
    <div class="meta-item"><span class="meta-label">Budget Ceiling</span><span class="meta-value">${budget_ceiling:,.0f}</span></div>
  </div>
  <div class="section">
    <div class="section-title">&#10003; Shortlisted Vendors ({len(shortlist)} selected)</div>
    <table>
      <thead><tr><th style="width:42px;">#</th><th>Vendor</th><th style="text-align:right;">Bid (USD)</th><th style="text-align:center;">Lead Time</th><th style="text-align:center;">Payment</th><th style="min-width:130px;">Score</th><th>Selection Reason</th></tr></thead>
      <tbody>{shortlist_rows}</tbody>
    </table>
  </div>
  <div class="section">
    <div class="section-title">Scoring Weights Applied</div>
    <table class="weights-table">
      <thead><tr><th>Criterion</th><th style="text-align:center;">Weight</th></tr></thead>
      <tbody>{weight_rows}</tbody>
    </table>
  </div>
  <div class="section">
    <div class="section-title">Procurement Recommendation</div>
    <div class="rec-box"><strong>Suggested PO Volume Split</strong>Distribute purchase orders across shortlisted vendors as follows. Procurement manager to confirm before PO issuance.</div>
    <table style="max-width:500px;">
      <thead><tr><th>Allocation</th><th>Share</th><th>Vendor</th></tr></thead>
      <tbody>{split_rows}</tbody>
    </table>
  </div>
  <div class="section">
    <div class="section-title">Vendors Not Selected ({len(dropped)})</div>
    <table>
      <thead><tr><th>Vendor</th><th style="text-align:right;">Bid (USD)</th><th style="text-align:center;">Lead Time</th><th style="text-align:center;">Score</th><th>Reason for Exclusion</th></tr></thead>
      <tbody>{dropped_rows}</tbody>
    </table>
  </div>
  <div class="section">
    <div class="section-title">Next Steps</div>
    <ul class="checklist">
      <li>Procurement manager review and sign-off on shortlist above</li>
      <li>PO issuance via ERP &mdash; reference this document ({rfq_id})</li>
      <li>Delivery follow-up reminder: <strong>{delivery_followup_date}</strong> &mdash; add to your calendar</li>
      <li>Send feedback emails to non-selected vendors (rfq-email-composer can draft these)</li>
      <li>Update vendor performance scores in master sheet post-delivery</li>
    </ul>
  </div>
  <div class="footer">
    <span>Generated by Joule Work Desktop &mdash; RFQ Pipeline &middot; {today_str}</span>
    <span>Scoring data: <code>{bid_log_path}</code></span>
  </div>
</div>
</body>
</html>"""
    return html
```

---

## Step R2 — Save HTML to Output/

```python
import os
BASE       = "/Users/I031973/Downloads/Agent_Dev_Workshop/RFQ_Agent_Joule"
OUTPUT_DIR = f"{BASE}/Output"
os.makedirs(OUTPUT_DIR, exist_ok=True)

html_path = os.path.join(OUTPUT_DIR, f"RFQ-Summary-{rfq_id}.html")
with open(html_path, "w", encoding="utf-8") as f:
    f.write(html_content)
```

---

## Step R3 — Convert HTML to PDF via WeasyPrint

```python
def html_to_pdf(html_path, pdf_path):
    try:
        from weasyprint import HTML
        HTML(filename=html_path).write_pdf(pdf_path)
        return True
    except ImportError:
        import subprocess, shutil
        if shutil.which("wkhtmltopdf"):
            result = subprocess.run([
                "wkhtmltopdf", "--quiet",
                "--margin-top", "15mm", "--margin-bottom", "20mm",
                "--margin-left", "15mm", "--margin-right", "15mm",
                html_path, pdf_path
            ], capture_output=True)
            return result.returncode == 0
        return False
    except Exception as e:
        print(f"PDF generation failed: {e}")
        return False

pdf_path = os.path.join(OUTPUT_DIR, f"RFQ-Summary-{rfq_id}.pdf")
pdf_ok   = html_to_pdf(html_path, pdf_path)
```

If PDF fails, proceed with HTML only. Note the failure in the chat response.
