---
name: rfq-vendor-finalizer
description: >-
  Produces the final shortlist of 5 vendors from ranked bid evaluations, generates an HTML report and PDF summary saved to Output/, updates the local bid log Shortlist and RFQEvents tabs, and closes the RFQ. Activate when the orchestrator delegates Phase 5, or when user says 'finalise vendors', 'close RFQ', 'who are the top 5', 'produce the shortlist'. Writes justifications mentioning disruption penalties where applied. Provides delivery follow-up date for user to add to their calendar. This skill CLOSES the RFQ cycle.
metadata:
  author: meridian-procurement
  version: 4.0.0
  tags: procurement shortlist finalization rfq html pdf meridian
---

## Overview

You are the **RFQ Closing Officer** for Meridian Industrial Systems. You produce
the final shortlist of 5 vendors, generate a professional HTML/PDF report in
`Output/`, close the RFQ in HANA, and give the user everything needed
to issue purchase orders.

## When to Use

- Orchestrator delegates Phase 5
- User says: "finalise vendors", "close RFQ", "who are the top 5", "produce the shortlist"

## Configuration

```python
# ── HANA Connection ────────────────────────────────────────────────────────
HANA_HOST     = "ecf4486c-c6ab-4def-bd2b-0ea86311835e.hna1.prod-us10.hanacloud.ondemand.com"
HANA_PORT     = 443
HANA_USER     = "DBADMIN"
HANA_PASSWORD = "Institute2026"
HANA_SCHEMA   = "DBADMIN"
OUTPUT_DIR    = "/Users/I031973/Documents/Joule_Desktop/RFQ_Agent_Joule/Output"

from hdbcli import dbapi
from datetime import datetime, timedelta
import os

def get_conn():
    return dbapi.connect(
        address=HANA_HOST, port=HANA_PORT,
        user=HANA_USER, password=HANA_PASSWORD,
        encrypt=True, sslValidateCertificate=False
    )

def hana_read(sql, params=None):
    conn = get_conn()
    cur  = conn.cursor()
    cur.execute(sql, params or [])
    cols = [d[0] for d in cur.description]
    rows = [dict(zip(cols, row)) for row in cur.fetchall()]
    cur.close(); conn.close()
    return rows

def hana_exec(sql, params=None):
    conn = get_conn()
    cur  = conn.cursor()
    cur.execute(sql, params or [])
    conn.commit()
    cur.close(); conn.close()

os.makedirs(OUTPUT_DIR, exist_ok=True)
```

---

## Procedure

### Step 1 — Load ranked evaluations from HANA

```python
eval_rows = hana_read(
    'SELECT * FROM "DBADMIN"."BIDEVALUATION" WHERE rfq_id=? '
    'ORDER BY composite_score DESC',
    [rfq_id]
)
# Take the most recent evaluation run (highest eval timestamp per vendor)
seen = set()
deduped = []
for row in eval_rows:
    vid = row.get("vendor_id")
    if vid not in seen:
        deduped.append(row)
        seen.add(vid)

evaluations = deduped
shortlist   = evaluations[:5]
dropped     = evaluations[5:]
```

### Step 2 — Generate justifications and drop reasons

```python
def justification(bid, rank, all_evals):
    reasons = []
    if float(bid.get("price_score",0)) == max(float(b.get("price_score",0)) for b in all_evals):
        reasons.append(f"lowest bid price (${float(bid.get('bid_total_usd',0)):,.0f})")
    delivery_days = float(bid.get("delivery_days", 99))
    eff_days      = float(bid.get("effective_delivery_days", delivery_days))
    required_days = float(bid.get("available_days", 65))
    if eff_days <= required_days * 0.85:
        days_ahead = int(required_days - eff_days)
        reasons.append(f"delivery {int(eff_days)} days — {days_ahead}d ahead of requirement")
    if float(bid.get("disruption_penalty_pct", 0)) == 0 and any(
        float(b.get("disruption_penalty_pct",0)) > 0 for b in all_evals
    ):
        reasons.append("unaffected by active supply chain disruptions")
    if not reasons:
        reasons.append(f"composite score {float(bid.get('composite_score',0)):.1f} — balanced across all criteria")
    return f"Rank #{rank}: {', '.join(reasons)}."

def drop_reason(bid, rank, all_evals):
    budget_ceiling = float(bid.get("budget_ceiling", 82000))
    if float(bid.get("bid_total_usd",0)) > budget_ceiling * 1.05:
        over = ((float(bid["bid_total_usd"]) / budget_ceiling) - 1) * 100
        return f"Bid ${float(bid['bid_total_usd']):,.0f} exceeds budget by {over:.0f}%."
    eff_days = float(bid.get("effective_delivery_days", bid.get("delivery_days", 0)))
    required_days = 65  # fallback
    if eff_days > required_days * 1.15:
        late = int(eff_days - required_days)
        return f"Effective delivery {int(eff_days)} days (incl. disruption penalty) — {late}d beyond requirement."
    return f"Composite score {float(bid.get('composite_score',0)):.1f} — ranked #{rank} of {len(all_evals)}."

for i, b in enumerate(shortlist):
    b["justification"] = justification(b, i+1, evaluations)
for i, b in enumerate(dropped):
    b["drop_reason"] = drop_reason(b, i+6, evaluations)
```

### Step 3 — Generate HTML report

Use the template in `references/report-generation.md` — `build_html_report()`.

```python
html_content = build_html_report(
    rfq_id=rfq_id, work_order_id=work_order_id, category=category,
    rfq_issue_date=rfq_issue_date, shortlist=shortlist, dropped=dropped,
    weights=weights, budget_ceiling=budget_ceiling,
    delivery_followup_date=delivery_followup_date, bid_log_path="HANA: DBADMIN schema"
)
html_path = os.path.join(OUTPUT_DIR, f"RFQ-Summary-{rfq_id}.html")
with open(html_path, "w", encoding="utf-8") as f:
    f.write(html_content)
```

### Step 4 — Convert to PDF

```python
pdf_path = os.path.join(OUTPUT_DIR, f"RFQ-Summary-{rfq_id}.pdf")
pdf_ok   = False
try:
    from weasyprint import HTML
    HTML(filename=html_path).write_pdf(pdf_path)
    pdf_ok = True
except Exception as e:
    import shutil, subprocess
    if shutil.which("wkhtmltopdf"):
        r = subprocess.run(
            ["wkhtmltopdf","--quiet","--margin-top","15mm",
             "--margin-bottom","20mm", html_path, pdf_path],
            capture_output=True
        )
        pdf_ok = r.returncode == 0
    if not pdf_ok:
        print(f"PDF generation failed: {e}. Proceeding HTML only.")
```

### Step 5 — Update HANA — Shortlist + RFQEvents

```python
today_date = datetime.now().strftime("%Y-%m-%d")

# Write shortlist rows
for i, b in enumerate(shortlist):
    hana_exec(
        'INSERT INTO "DBADMIN"."SHORTLIST" '
        '(shortlist_id,rfq_id,work_order_id,vendor_id,vendor_name,rank,'
        'bid_total_usd,delivery_days,composite_score,justification,'
        'shortlisted_date,report_path) '
        'VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
        [
            f"SL-{rfq_id}-{b['vendor_id']}",
            rfq_id, work_order_id,
            b["vendor_id"], b["vendor_name"], i + 1,
            b.get("bid_total_usd"), b.get("delivery_days"),
            b.get("composite_score"), b["justification"],
            today_date, html_path
        ]
    )

# Close RFQ in RFQEvents
hana_exec(
    'UPDATE "DBADMIN"."RFQEVENTS" SET status=? WHERE rfq_id=?',
    ["closed", rfq_id]
)
print(f"[OK] Shortlist written to HANA. RFQ {rfq_id} marked closed.")
```

### Step 6 — Compute delivery follow-up date

```python
earliestdays  = min(float(b.get("delivery_days", 30)) for b in shortlist)
followup_dt   = datetime.now() + timedelta(days=int(earliestdays) - 3)
followup_date = followup_dt.strftime("%Y-%m-%d")
```

### Step 7 — Report final results in chat

```python
shortlist_lines = "\n".join(
    f"{i+1}. {b['vendor_name']} — ${float(b.get('bid_total_usd',0)):,.0f}"
    f" — {b.get('delivery_days')} days — Score: {float(b.get('composite_score',0)):.1f}"
    for i, b in enumerate(shortlist)
)
file_links = f"HTML Report: {html_path}"
if pdf_ok:
    file_links += f"\nPDF Report:  {pdf_path}"

print(
    f"RFQ {rfq_id} CLOSED\n\n"
    f"Shortlisted vendors:\n{shortlist_lines}\n\n"
    f"{file_links}\nHANA: DBADMIN.SHORTLIST updated\n\n"
    f"Please add a calendar reminder for {followup_date}:\n"
    f"'Delivery follow-up: {rfq_id} — confirm delivery with shortlisted vendors.'"
)
```

---

## Edge cases

- **Fewer than 5 bids**: Shortlist all; add banner "Note: Fewer than 5 bids received."
- **PDF fails**: HTML only. Note in chat.
- **Duplicate shortlist entry**: Check before INSERT with `SELECT shortlist_id FROM SHORTLIST WHERE rfq_id=? AND vendor_id=?`.
- **HANA connection error**: Report error; do not generate partial shortlist.

## Common Pitfalls

1. **Vague justifications.** Name actual numbers — days ahead, price delta.
2. **Forgetting to mark RFQ closed** in HANA RFQEVENTS.
3. **Writing reports to wrong path.** Always use `OUTPUT_DIR`.
4. **Blocking on PDF failure.** PDF is a bonus — never block the pipeline.
5. **Duplicate shortlist rows.** Check for existing SL-{rfq_id}-{vendor_id} before INSERT.

## Verification Checklist

- [ ] Ranked evaluations loaded from HANA BIDEVALUATION
- [ ] Top 5 shortlisted; remainder dropped
- [ ] Justification written for each (specific, numeric)
- [ ] Drop reason written for each excluded vendor
- [ ] HTML report generated and saved to Output/
- [ ] PDF generated or failure noted gracefully
- [ ] Shortlist rows inserted in HANA SHORTLIST
- [ ] HANA RFQEVENTS row updated to 'closed'
- [ ] Delivery follow-up date given to user for calendar
- [ ] Final summary reported in chat

## References

- `references/report-generation.md` — Full HTML template (build_html_report()), WeasyPrint PDF