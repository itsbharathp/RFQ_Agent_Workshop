# Local Data Navigation Patterns — Meridian Datasets

```python
import os, pandas as pd
from openpyxl import load_workbook

BASE         = "/Users/I031973/Downloads/Agent_Dev_Workshop/RFQ_Agent_Joule"
DATA_DIR     = f"{BASE}/Data"
BID_LOG_FILE = f"{DATA_DIR}/MERIDIAN_SHEETS_BID_LOG_ID.xlsx"
VENDOR_FILE  = f"{DATA_DIR}/MERIDIAN_VENDOR_SHEET_ID.xlsx"
```

## Pattern 1: Read a tab as list of dicts (pandas)
```python
df   = pd.read_excel(BID_LOG_FILE, sheet_name="RFQInvites")
rows = df[df["rfq_id"] == "RFQ-0065"].to_dict(orient="records")
```

## Pattern 2: Find a specific row by value (openpyxl)
```python
wb     = load_workbook(BID_LOG_FILE)
ws     = wb["RFQEvents"]
for row in ws.iter_rows(min_row=2):
    if row[0].value == "RFQ-0065":
        print(f"Found at row {row[0].row}")
        break
```

## Pattern 3: Append a new row
```python
wb = load_workbook(BID_LOG_FILE)
wb["Bids"].append([col1, col2, col3])
wb.save(BID_LOG_FILE)
```

## Pattern 4: Update a specific cell
```python
wb = load_workbook(BID_LOG_FILE)
ws = wb["RFQEvents"]
for row in ws.iter_rows(min_row=2):
    if row[0].value == "RFQ-0065":
        row[10].value = "closed"   # column K = status
        break
wb.save(BID_LOG_FILE)
```

## Pattern 5: Deduplication check
```python
rfq_df         = pd.read_excel(BID_LOG_FILE, sheet_name="RFQEvents")
already_exists = "RFQ-0065" in rfq_df.iloc[:, 0].astype(str).values
```

## Pattern 6: Batch-update many rows
```python
wb = load_workbook(BID_LOG_FILE)
ws = wb["EmailLog"]
for row in ws.iter_rows(min_row=2):
    if row[3].value == "old@example.com":   # column D = vendor_email
        row[3].value = "new@example.com"
wb.save(BID_LOG_FILE)
```

## Common Pitfalls

1. **Not saving after write** — every `load_workbook` edit cycle needs `wb.save()`.
2. **Column index confusion** — `row[0]` = column A, `row[10]` = column K.
3. **Mixed types after Excel read** — use `pd.to_numeric(..., errors="coerce")` and `pd.to_datetime(...)` to normalise.
4. **RFQ duplication** — always check `RFQEvents` before creating new RFQ events.
