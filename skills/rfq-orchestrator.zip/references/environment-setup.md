# RFQ Environment Setup — Joule Work Desktop

The RFQ skills use local Excel files for all data storage. Email reading uses
Joule Work Desktop's built-in Outlook tools. Email drafts are saved to
`Output/Emails/` for the user to send from their Outlook client.

## Data Folder Layout

```
/Users/I031973/Documents/Joule_Desktop/RFQ_Agent_Joule/
├── Data/
│   ├── MERIDIAN_SHEETS_BID_LOG_ID.xlsx   ← main bid log (all pipeline tabs)
│   ├── MERIDIAN_VENDOR_SHEET_ID.xlsx     ← vendor master (Vendors tab)
│   └── *.csv                             ← historical reference data
├── Input/                                ← uploaded work order files
└── Output/
    ├── Emails/                           ← per-vendor email draft .txt files
    ├── RFQ-Spec-*.txt                    ← RFQ specification documents
    ├── RFQ-Summary-*.html                ← closure reports
    └── RFQ-Summary-*.pdf                 ← closure report PDFs
```

## Python Base Path

All skills use this hardcoded base path in Python scripts:

```python
BASE               = "/Users/I031973/Documents/Joule_Desktop/RFQ_Agent_Joule"
DATA_DIR           = f"{BASE}/Data"
INPUT_DIR          = f"{BASE}/Input"
OUTPUT_DIR         = f"{BASE}/Output"
BID_LOG_FILE       = f"{DATA_DIR}/MERIDIAN_SHEETS_BID_LOG_ID.xlsx"
VENDOR_FILE        = f"{DATA_DIR}/MERIDIAN_VENDOR_SHEET_ID.xlsx"
PROCUREMENT_EMAIL  = "bharath.prasad@sap.com"
```

## PROCUREMENT_EMAIL

The sender email is hardcoded as `bharath.prasad@sap.com` in all skills.
No environment variable setup is required.

## Email Operations

| Operation | How it works |
|---|---|
| Draft RFQ emails | rfq-email-composer writes .txt files to `Output/Emails/`. User sends from Outlook. |
| Read bid replies | rfq-email-tracker uses `search_emails` and `get_email` built-in tools. |
| Draft nudge reminders | rfq-email-tracker writes nudge .txt files. User sends from Outlook. |

## Calendar Reminders

Joule Work Desktop does not create calendar events automatically. The pipeline
provides exact dates and text so you can add them to your calendar manually.

## Python Dependencies

Already installed. If reinstall is needed:
```bash
pip install openpyxl pandas pdfplumber python-dateutil weasyprint
```

## First-time Setup

The data files must be copied once to the Joule_Desktop working folder:
```bash
bash /Users/I031973/Documents/Joule_Desktop/setup_rfq_data.sh
```
