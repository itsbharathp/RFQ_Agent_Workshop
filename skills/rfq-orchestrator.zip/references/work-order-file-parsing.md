# Work Order File Parsing Reference

The RFQ orchestrator accepts work orders as Excel (.xlsx/.xls) or PDF files.
Joule Work Desktop's `read_file` tool extracts content from all supported
formats natively — use it first, then apply AI reasoning to structure the data.

---

## Step A — Read the file

Call `read_file` on the uploaded file path. It returns extracted content as text.

| Format | Notes |
|---|---|
| `.xlsx`, `.xls` | Extracts cell values as structured text |
| `.pdf` (digital) | Extracts text layer automatically |
| `.pdf` (scanned) | Built-in OCR fallback |

---

## Step B — Extract structured data using AI reasoning

From the extracted text, identify and structure these fields:

**Top-level work order fields:**
- `work_order_id` — string (WO-YYYY-NNNN format)
- `category` — one of "Mechanical Parts", "Electrical Components", "Raw Materials" (infer from items if not stated)
- `urgency_level` — one of "standard", "expedited", "critical" (default "standard")
- `budget_ceiling_usd` — number (USD, null if not found)
- `required_by_date` — ISO date YYYY-MM-DD (use earliest item date if no header date)
- `procurement_manager` — string or null
- `sales_order_ref` — string or null

**Items array (one per line item):**
- `description` — string
- `category` — string
- `quantity` — number
- `unit` — string (pcs, m, kg, etc.)
- `target_unit_price_usd` — number or null
- `required_by_date` — ISO date YYYY-MM-DD or null

---

## Expected Excel layout (clean template)

```
Row 1:  Work Order ID  | WO-2024-0071
Row 2:  Sales Order    | SO-2024-0055
Row 3:  Manager        | Meena Krishnan
Row 4:  Category       | Mechanical Parts
Row 5:  Urgency        | expedited
Row 6:  Budget (USD)   | 54457
Row 7:  Required By    | 2024-08-05
Row 8:  (blank)
Row 9:  Description | Category | Qty | Unit | Target Price | Required By
Row 10+: line items...
```

---

## Step C — Validate extracted data

```python
VALID_CATEGORIES = {"Mechanical Parts", "Electrical Components", "Raw Materials"}
VALID_URGENCY    = {"standard", "expedited", "critical"}

def validate_work_order(wo: dict):
    errors = []
    if not wo.get("work_order_id"):
        errors.append("work_order_id missing — could not find WO-YYYY-NNNN pattern")
    if wo.get("category") not in VALID_CATEGORIES:
        errors.append(f"category '{wo.get('category')}' not recognised. Expected: {', '.join(VALID_CATEGORIES)}")
    if wo.get("urgency_level") not in VALID_URGENCY:
        wo["urgency_level"] = "standard"
    if not wo.get("required_by_date"):
        errors.append("required_by_date missing — cannot compute bid deadline")
    if not wo.get("items"):
        errors.append("No line items found — check the items table in your file")
    for i, item in enumerate(wo.get("items", [])):
        if not item.get("description"):
            errors.append(f"Item {i+1}: description missing")
        if not item.get("quantity"):
            errors.append(f"Item {i+1}: quantity missing")
    return len(errors) == 0, errors
```

If validation fails, present errors and ask for corrections. Do NOT proceed to Phase 1.

---

## Step D — Confirm with user

```
Work order parsed:

Work Order ID  : WO-2024-0071
Category       : Mechanical Parts
Urgency        : expedited
Budget ceiling : $54,457
Required by    : 2024-08-05

Items (4):
  1. Linear Guide Rail 1500mm — 38 pcs @ $158.30
  2. Copper Busbar 40x4mm — 63 m @ $20.38
  3. Encoder 2500 PPR Differential — 100 pcs @ $100.57
  4. Precision Ball Screw Assy 25mm — 79 pcs @ $385.23

Shall I save this and proceed with the RFQ?
(Reply "yes" to proceed, or correct any values above)
```

---

## Step E — Save to local bid log (if new)

```python
import pandas as pd, os, shutil
from openpyxl import load_workbook
from datetime import datetime

BASE         = "/Users/I031973/Downloads/Agent_Dev_Workshop/RFQ_Agent_Joule"
BID_LOG_FILE = f"{BASE}/Data/MERIDIAN_SHEETS_BID_LOG_ID.xlsx"

wo_df = pd.read_excel(BID_LOG_FILE, sheet_name="WorkOrders")
if work_order_id not in wo_df.iloc[:, 0].astype(str).values:
    wb = load_workbook(BID_LOG_FILE)
    wb["WorkOrders"].append([
        work_order_id, sales_order_ref, procurement_manager,
        category, urgency_level, budget_ceiling_usd,
        required_by_date, datetime.now().isoformat()
    ])
    for item in items:
        wb["WorkOrderItems"].append([
            work_order_id, item["description"], item["category"],
            item["quantity"], item["unit"],
            item.get("target_unit_price_usd"), item.get("required_by_date")
        ])
    wb.save(BID_LOG_FILE)
```

## Step F — Archive source file to Input/

```python
INPUT_DIR = f"{BASE}/Input"
os.makedirs(INPUT_DIR, exist_ok=True)
ext  = os.path.splitext(uploaded_file_path)[1]
dest = os.path.join(INPUT_DIR, f"WO-Source-{work_order_id}{ext}")
shutil.copy(uploaded_file_path, dest)
```
