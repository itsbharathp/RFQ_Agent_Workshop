# RFQ Pipeline — Session Patterns and Pitfalls

## Email Draft Files

RFQ emails are drafted as `.txt` files in `Output/Emails/`. Each file format:

```
TO: vendor@example.com
SUBJECT: Request for Quotation - RFQ-XXXX - Mechanical Parts
ATTACHMENT: /Users/I031973/Downloads/Agent_Dev_Workshop/RFQ_Agent_Joule/Output/RFQ-Spec-RFQ-XXXX.txt
---
Dear {Contact Name},

{personalised email body}

Best regards,
Meridian Procurement
{PROCUREMENT_EMAIL}
```

## Recipient Override Pattern

Before drafting RFQ emails, always ask:
> "Shall I use the vendor contacts on file, or would you like to use a
> different address for this RFQ (e.g., for testing or a shared inbox)?"

## Email Subject Prefixes by Urgency

| Urgency | Prefix | Example |
|---------|--------|---------|
| standard | (none) | `Request for Quotation - RFQ-0203 - Mechanical Parts` |
| expedited | `EXPEDITED:` | `EXPEDITED: Request for Quotation - RFQ-0203 - Mechanical Parts` |
| critical | `URGENT:` | `URGENT: Request for Quotation - RFQ-0203 - Mechanical Parts` |

Use text-only prefixes — emoji may be stripped by some email clients.

## EmailLog Tab Schema (Joule Work Desktop)

| Column | Value |
|---|---|
| rfq_id | RFQ-XXXX |
| vendor_id | V001 |
| drafted_at | ISO datetime |
| vendor_email | contact@vendor.com |
| outlook_message_id | Populated by tracker when it identifies a reply |
| status | drafted → sent → acknowledged / bid_received / query_received / declined |
| deadline | YYYY-MM-DD |

## Bid Logging Workflow

When a bid reply arrives (found via `search_emails`):
1. **Classify** using subject + body (bid / ack / query / decline)
2. **Extract bid data** using AI reasoning from email body
3. **Log to Bids tab** in `Data/MERIDIAN_SHEETS_BID_LOG_ID.xlsx`
4. **Update EmailLog** — mark vendor as responded

## Local File Write Patterns

### Append a row
```python
from openpyxl import load_workbook
BASE         = "/Users/I031973/Downloads/Agent_Dev_Workshop/RFQ_Agent_Joule"
BID_LOG_FILE = f"{BASE}/Data/MERIDIAN_SHEETS_BID_LOG_ID.xlsx"

wb = load_workbook(BID_LOG_FILE)
wb["TabName"].append([col1, col2, col3])
wb.save(BID_LOG_FILE)
```

### Find and update a row
```python
wb = load_workbook(BID_LOG_FILE)
ws = wb["RFQEvents"]
for row in ws.iter_rows(min_row=2):
    if row[0].value == target_rfq_id:
        row[10].value = "closed"
        break
wb.save(BID_LOG_FILE)
```

### Read a tab as dicts
```python
import pandas as pd
df      = pd.read_excel(BID_LOG_FILE, sheet_name="TabName")
records = df.to_dict(orient="records")
```

## Common Data Issues

### Disputes Tab — No resolved column
Apply a proportional penalty instead of hard-excluding vendors:
```python
dispute_penalty = dispute_count * 0.05
composite_score = (price * 0.40) + (on_time * 0.30) + (quality * 0.20) - dispute_penalty
```

### Work Order Not in Bid Log
1. Confirm category with user
2. Use WO ID and budget from the user's message
3. Generate next sequential RFQ ID (e.g., RFQ-0203)
4. Write new event to `RFQEvents` and `RFQInvites` tabs
