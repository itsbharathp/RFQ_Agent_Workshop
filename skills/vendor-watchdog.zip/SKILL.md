---
name: vendor-watchdog
description: >-
  Autonomous vendor health monitoring agent for Meridian Industrial Systems. Queries live HANA database to detect at-risk vendors BEFORE they become unusable, diagnoses root causes (Meridian-caused vs Performance-caused vs Market-caused), and generates structured alerts with specific, timeline-bound recommendations. Also surfaces positive vendor opportunities. Activate when user says "run watchdog", "check vendor health", "vendor health analysis", "which vendors are at risk", "vendor risk report", "watchdog report", "monitor vendors", "run health check", "vendor monitoring", or any request about vendor health status, risk alerts, or supplier deterioration.
allowed-tools: mcp_9e26561d_hana_execute_query render_ui add_card_to_space create_space write_file
metadata:
  author: SAP Academy for Product and Engineering
  version: 1.0.0
  tags: vendor-management procurement monitoring hana agentic meridian alerts risk
  required-mcp-servers: "localhost:8808/mcp"
---

# The Watchdog — Vendor Health Monitoring Agent

Autonomous vendor health monitor for Meridian Industrial Systems. Query live HANA data to detect at-risk vendors, diagnose root causes, and generate actionable alerts with specific remediation steps.

The key difference from a rule-based alert system: reason about WHY a vendor is declining, not just THAT a threshold was crossed. Surface both risks and opportunities.

---

## Prerequisites

Verify the **HANA PBC** MCP connector is active. If it is not connected, stop immediately and tell the user: "The HANA PBC connector must be enabled under Settings → Connectors before I can run the Watchdog."

---

## Step 1 — Determine the Analysis Month

If the user specified a month number (e.g. "run watchdog for month 10"), use that as `{month_index}`.

If the user says "latest" or provides no month, execute:
```sql
SELECT MAX(MONTH_INDEX) AS CURRENT_MONTH FROM DBADMIN.VENDOR_HEALTH_SCORES
```
Use the returned value as `{month_index}`.

Tell the user: "Running Watchdog analysis for month {month_index}..."

---

## Step 2 — Health Snapshot

Execute this query to retrieve all vendor scores for the target month:
```sql
SELECT 
    VENDOR_ID,
    VENDOR_NAME,
    COMPOSITE_HEALTH_SCORE,
    TREND_3MO,
    ALERT_FLAG,
    ALERT_REASON,
    PAYMENT_RELIABILITY_SCORE,
    WIN_RATE_SCORE,
    ADMIN_BURDEN_SCORE,
    RELATIONSHIP_ARC,
    THIN_DATA_FLAG
FROM DBADMIN.VENDOR_HEALTH_SCORES
WHERE MONTH_INDEX = {month_index}
ORDER BY COMPOSITE_HEALTH_SCORE ASC
```

Display the full results as a table card (`render_ui`, `hint="table"`, size L). Title: "Vendor Health Snapshot — Month {month_index}".

**Build the investigation list** from these results:

- **AT_RISK**: vendors where ALERT_FLAG = 'True', OR (COMPOSITE_HEALTH_SCORE < 80 AND TREND_3MO = 'declining')
- **POSITIVE**: vendors where RELATIONSHIP_ARC = 'improving' (check for >8pt gain after trend data)
- **SKIP**: vendors where THIN_DATA_FLAG = 'True' AND COMPOSITE_HEALTH_SCORE > 60 — insufficient data, do not alert

---

## Step 3 — Deep Investigation (Parallel Per Vendor)

For EACH vendor in AT_RISK and POSITIVE lists, execute all four queries **simultaneously in a single message** (four tool calls in one turn). Do not investigate vendors sequentially.

Replace `{vendor_id}` and `{month_index}` in each query.

### Query A — 6-Month Health Trend
```sql
SELECT 
    MONTH_INDEX, 
    COMPOSITE_HEALTH_SCORE, 
    TREND_3MO,
    PAYMENT_RELIABILITY_SCORE, 
    WIN_RATE_SCORE, 
    ADMIN_BURDEN_SCORE,
    RELATIONSHIP_ARC
FROM DBADMIN.VENDOR_HEALTH_SCORES
WHERE VENDOR_ID = '{vendor_id}'
  AND MONTH_INDEX BETWEEN GREATEST(0, {month_index} - 5) AND {month_index}
ORDER BY MONTH_INDEX ASC
```
Calculate `score_change` = last score − first score. A large negative change is a strong signal.

### Query B — Payment History (6 months)
```sql
SELECT 
    MONTH_INDEX, 
    PO_VALUE_USD, 
    PAYMENT_STATUS,
    DAYS_LATE, 
    DAYS_EARLY, 
    MERIDIAN_STRESS_INDEX
FROM DBADMIN.PAYMENT_EVENTS
WHERE VENDOR_ID = '{vendor_id}'
  AND MONTH_INDEX BETWEEN GREATEST(0, {month_index} - 5) AND {month_index}
ORDER BY MONTH_INDEX ASC
```
Check for: PAYMENT_STATUS IN ('late','disputed') OR DAYS_LATE > 5. If yes, Meridian may be causing the vendor's disengagement.

### Query C — Dispute History (all time)
```sql
SELECT 
    DISPUTE_ID, 
    DISPUTE_DATE, 
    REASON, 
    CLAIMED_USD, 
    RESOLVED, 
    RESOLUTION
FROM DBADMIN.VENDOR_DISPUTES
WHERE VENDOR_ID = '{vendor_id}'
ORDER BY DISPUTE_DATE DESC
```
Count open disputes (RESOLVED = 'False'). Note dispute reasons — 'quality_issue' or 'delivery_delay' signal Performance-caused root cause.

### Query D — RFQ Participation (6 months)
```sql
SELECT 
    i.MONTH_INDEX,
    COUNT(i.INVITE_ID) AS N_INVITED,
    SUM(CASE WHEN i.RESPONDED = 'True' THEN 1 ELSE 0 END) AS N_RESPONDED,
    COUNT(e.EVAL_ID) AS N_BIDS,
    SUM(CASE WHEN e.SELECTED = 'True' THEN 1 ELSE 0 END) AS N_WON
FROM DBADMIN.RFQ_VENDOR_INVITES i
LEFT JOIN DBADMIN.BID_EVALUATION e 
    ON i.VENDOR_ID = e.VENDOR_ID 
   AND i.MONTH_INDEX = e.MONTH_INDEX
WHERE i.VENDOR_ID = '{vendor_id}'
  AND i.MONTH_INDEX BETWEEN GREATEST(0, {month_index} - 5) AND {month_index}
GROUP BY i.MONTH_INDEX
ORDER BY i.MONTH_INDEX ASC
```
Compute: total_invited, total_responded, response_rate = responded/invited, win_rate = won/invited. Low response rate (< 50%) with no payment issues = silent disengagement.

**If investigating multiple vendors**: execute all four queries for ALL vendors in a single parallel batch — do not wait between vendors.

---

## Step 4 — Root Cause Classification

For each investigated vendor, classify the root cause BEFORE generating the alert:

| Root Cause | Evidence Pattern |
|---|---|
| **Meridian-caused** | PAYMENT_STATUS IN ('late','disputed') OR DAYS_LATE > 5 in recent months. Meridian's behaviour is triggering vendor disengagement. Fix: prioritise on-time payment. |
| **Performance-caused** | Disputes with REASON = 'quality_issue' or 'delivery_delay'. Low ON_TIME_DELIVERY or high DEFECT_RATE. Fix: qualify alternatives. |
| **Market-caused** | RELATIONSHIP_ARC = 'collapse' with no Meridian payment issues. Structural external decline. Fix: plan replacement. |
| **Engagement decline** | Response rate < 50% despite acceptable payments. Vendor prioritising other clients. Fix: offer preferred RFQ slots. |
| **New vendor uncertainty** | THIN_DATA_FLAG = 'True' with MONTH_INDEX < 4. Insufficient track record. Do not over-alert. |

---

## Step 5 — Alert Severity Rules

Apply these rules in order — first match wins:

- **CRITICAL**: COMPOSITE_HEALTH_SCORE < 60 OR (RELATIONSHIP_ARC = 'collapse' AND COMPOSITE_HEALTH_SCORE < 65)
- **HIGH**: COMPOSITE_HEALTH_SCORE < 75 AND TREND_3MO = 'declining'
- **MEDIUM**: COMPOSITE_HEALTH_SCORE < 80 AND TREND_3MO = 'declining'
- **LOW**: COMPOSITE_HEALTH_SCORE < 85 AND TREND_3MO = 'declining' (early warning)
- **POSITIVE**: Score improved > 8 points over last 3 months (opportunity alert)
- **NO ALERT**: THIN_DATA_FLAG = 'True' AND score > 60; OR stable score > 75 — do not generate an alert

---

## Step 6 — Recommendation Rules (Non-Negotiable)

NEVER write "monitor closely" — that is not a recommendation.

Every recommended action MUST include:
1. A **specific action** (e.g. "prioritise on-time payment", "offer 2 upcoming RFQ slots", "begin removal planning", "initiate forecast sharing programme")
2. A **timeline** (e.g. "next payment cycle", "within 30 days", "next 2 RFQs")

Additional rules:
- **CRITICAL vendors**: Recommend removal from active RFQ pool AND name a replacement. To find a replacement, execute:
  ```sql
  SELECT v.VENDOR_ID, v.VENDOR_NAME, h.COMPOSITE_HEALTH_SCORE
  FROM DBADMIN.VENDOR_HEALTH_SCORES h
  JOIN DBADMIN.VENDORS v ON v.VENDOR_ID = h.VENDOR_ID
  WHERE h.MONTH_INDEX = {month_index}
    AND h.COMPOSITE_HEALTH_SCORE > 80
    AND h.TREND_3MO IN ('stable','improving')
    AND v.CATEGORY = (SELECT CATEGORY FROM DBADMIN.VENDORS WHERE VENDOR_ID = '{at_risk_vendor_id}')
    AND v.VENDOR_ID != '{at_risk_vendor_id}'
  ORDER BY h.COMPOSITE_HEALTH_SCORE DESC
  LIMIT 3
  ```
- **Meridian-caused**: "Prioritise [vendor_name] for on-time payment in the NEXT payment cycle. After normalisation, offer preferred right-of-first-refusal on the next 2–3 RFQs to rebuild the win-rate score."
- **Collapse arc approaching critical**: "Do not increase RFQ allocation to [vendor_name]. Begin removal planning and accelerate qualification of [replacement_vendor]."
- **POSITIVE alerts**: "Initiate [specific_action] with [vendor_name] this month. Offer preferred status in upcoming RFQs. This vendor's trajectory makes them a strategic partner candidate."

---

## Step 7 — Output

### 7a. Alert Object-List Card
Display all generated alerts as a `render_ui` object-list card (hint="object-list", size XL). Each item shows:
- **Severity** badge (CRITICAL / HIGH / MEDIUM / LOW / POSITIVE)
- Vendor name and ID
- Composite score → trend arrow (↓ declining, → stable, ↑ improving)
- Root cause (one sentence)
- Recommended action (specific with timeline)
- Urgency tag

### 7b. Evidence Summary Table
Display a `render_ui` table card (hint="table", size L) for all investigated vendors:

| Vendor | Score | Trend | Severity | Root Cause Type | Urgency |
|---|---|---|---|---|---|

### 7c. Urgency Mapping

| Severity | Urgency |
|---|---|
| CRITICAL | act_this_month |
| HIGH | act_this_month |
| MEDIUM | act_this_quarter |
| LOW | monitor |
| POSITIVE | opportunity |

### 7d. Save Option
After displaying results, ask: "Would you like me to save the full Watchdog report as JSON? I'll write it to `watchdog_report_m{month_index}.json` in your working directory."

If yes, write the JSON file containing all alert objects with these fields per alert:
`vendor_id`, `vendor_name`, `alert_severity`, `composite_score`, `trend`, `root_cause`, `supporting_evidence` (array of strings), `recommended_action`, `urgency`

---

## Example Interactions

**User**: "Run watchdog for month 10"  
→ Execute Step 1 with month_index=10, proceed through all steps.

**User**: "Check vendor health for the latest month"  
→ Query MAX(MONTH_INDEX), then proceed.

**User**: "Which vendors are at risk?"  
→ Use latest month, focus output on AT_RISK vendors only.

**User**: "Watchdog — show me positive trends too"  
→ Include POSITIVE alerts in output alongside risk alerts.
