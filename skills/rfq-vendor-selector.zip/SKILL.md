---
name: rfq-vendor-selector
description: >-
  Selects the optimal 8 vendors to invite for an RFQ from the Meridian vendor master. Activate when the orchestrator delegates Phase 1, or when a user says 'which vendors should I invite for', 'pick vendors for RFQ', 'who should we send this RFQ to'. Reads vendor master from local Data files, applies a 100-point scoring model adjusted for urgency, filters disqualified vendors (high risk on critical orders, low financial health, open disputes), writes selection to RFQInvites tab, and returns the best 8 candidates with selection reasons.
metadata:
  version: 4.0.0
---

## Overview

You are the **Vendor Selector** for Meridian Industrial Systems. Given a work
order's category, budget ceiling, and urgency, you score every eligible vendor
from the HANA VENDORS table and return the best 8 to invite.

## When to Use

- Orchestrator delegates Phase 1 (vendor selection)
- User asks: "which vendors should I invite for...", "pick vendors for RFQ",
  "who should we send this RFQ to"

## Configuration

```python
# ── HANA Connection ────────────────────────────────────────────────────────
HANA_HOST     = "ecf4486c-c6ab-4def-bd2b-0ea86311835e.hna1.prod-us10.hanacloud.ondemand.com"
HANA_PORT     = 443
HANA_USER     = "DBADMIN"
HANA_PASSWORD = "Institute2026"
HANA_SCHEMA   = "DBADMIN"

from hdbcli import dbapi
from datetime import datetime

def get_conn():
    return dbapi.connect(
        address=HANA_HOST, port=HANA_PORT,
        user=HANA_USER, password=HANA_PASSWORD,
        encrypt=True, sslValidateCertificate=False
    )

def hana_read(sql, params=None):
    conn = get_conn()
    cur  = conn.cursor()
    cur.execute(sql, params or [])
    cols = [d[0] for d in cur.description]
    rows = [dict(zip(cols, row)) for row in cur.fetchall()]
    cur.close(); conn.close()
    return rows

def hana_exec(sql, params=None):
    conn = get_conn()
    cur  = conn.cursor()
    cur.execute(sql, params or [])
    conn.commit()
    cur.close(); conn.close()
```

## Inputs expected

```
work_order_id:      WO-2024-NNNN
category:           Mechanical Parts | Electrical Components | Raw Materials
budget_ceiling_usd: 45000
required_by_date:   2024-09-15
urgency:            standard | expedited | critical
```

---

## Procedure

### Step 1 — Pull vendor master from HANA

```python
vendors = hana_read(
    'SELECT * FROM "DBADMIN"."VENDORS" WHERE category = ?',
    [category]
)
# If no vendors in exact category, try broader pull
if not vendors:
    vendors = hana_read('SELECT * FROM "DBADMIN"."VENDORS"')
    vendors = [v for v in vendors if v.get("category") == category]
```

### Step 2 — Filter disqualified vendors

Exclude if **any** are true:
- `risk_tier == "high"` AND `urgency == "critical"`
- `financial_health_score < 5.0`
- Vendor has an open dispute in the DISPUTES table

```python
open_dispute_rows = hana_read(
    'SELECT vendor_id FROM "DBADMIN"."DISPUTES" '
    'WHERE LOWER(CAST(resolved AS VARCHAR)) != \'true\''
)
open_disputes = {r["vendor_id"] for r in open_dispute_rows}

eligible = [
    v for v in vendors
    if v["vendor_id"] not in open_disputes
    and float(v.get("financial_health_score") or 0) >= 5.0
    and not (v.get("risk_tier") == "high" and urgency == "critical")
]

if not eligible:
    print(f"WARNING: All vendors excluded. Relaxing filters.")
    eligible = [v for v in vendors if v["vendor_id"] not in open_disputes]
```

### Step 3 — Score each vendor (100-point model)

```python
def score_vendor(v, urgency, budget_ceiling):
    price_score    = max(0, 25 * (1 - (float(v.get("base_price_index") or 1) - 0.80) / 0.55))
    otd_score      = 25 * float(v.get("base_otd_rate") or 0)
    quality_score  = 20 * (float(v.get("base_quality_score") or 0) / 10)
    rr_weight      = 30 if urgency == "critical" else 15
    response_score = rr_weight * float(v.get("base_response_rate") or 0)
    rel_score      = 10 * min(float(v.get("relationship_years") or 0), 10) / 10
    risk_penalty   = {"low": 0, "medium": -3, "high": -8}.get(v.get("risk_tier","low"), 0)
    return round(price_score + otd_score + quality_score + response_score + rel_score + risk_penalty, 2)

for v in eligible:
    v["score"] = score_vendor(v, urgency, budget_ceiling_usd)

top_8 = sorted(eligible, key=lambda x: x["score"], reverse=True)[:8]

if len(top_8) < 8:
    print(f"WARNING: Only {len(top_8)} eligible vendors found (target: 8).")
```

### Step 4 — Write selection to HANA RFQINVITES

```python
for v in top_8:
    hana_exec(
        'INSERT INTO "DBADMIN"."RFQINVITES" '
        '(rfq_id,work_order_id,vendor_id,vendor_name,contact_email,'
        'contact_name,score,status,invited_at) VALUES (?,?,?,?,?,?,?,?,?)',
        [
            rfq_id, work_order_id,
            v["vendor_id"], v["vendor_name"],
            v["contact_email"], v["contact_name"],
            v["score"], "invited",
            datetime.now().isoformat()
        ]
    )
print(f"[OK] {len(top_8)} vendors written to RFQINVITES for {rfq_id}")
```

### Step 5 — Format output for orchestrator

```json
{
  "rfq_id": "RFQ-0042",
  "work_order_id": "WO-2024-0042",
  "invited_vendors": [
    {
      "vendor_id": "V001",
      "vendor_name": "Kovacs Precision GmbH",
      "contact_email": "hans@kovacsprecision.com",
      "contact_name": "Hans Kovacs",
      "score": 87.3,
      "behavioral_archetype": "reliable",
      "selection_reason": "Top OTD rate (94%), strong relationship (8yr), price index 0.91"
    }
  ]
}
```

Also show a human-readable summary table.

---

## Scoring rubric

| Factor | Standard | Critical urgency |
|---|---|---|
| Price competitiveness | 25 | 20 |
| On-time delivery | 25 | 30 |
| Quality score | 20 | 20 |
| Response rate | 15 | 20 |
| Relationship depth | 10 | 5 |
| Risk/dispute penalties | deducted | deducted |

## Edge cases

- **All high-risk**: Relax filter, flag, recommend vendor review.
- **Fewer than 5 eligible**: Expand to adjacent categories.
- **New vendor no history**: Use `financial_health_score` as proxy. Flag for awareness.
- **HANA connection error**: Report error and stop — do not proceed with partial data.

## Common Pitfalls

1. **Forgetting to filter open disputes from HANA DISPUTES table.**
2. **Not adjusting weights for urgency.**
3. **Returning more than 8 vendors.**
4. **Using unquoted identifiers in HANA SQL** — always quote table and column names.

## Verification Checklist

- [ ] HANA VENDORS table queried and filtered by category
- [ ] Open disputes loaded from HANA DISPUTES table
- [ ] Disqualified vendors excluded
- [ ] 100-point scoring applied with urgency-adjusted weights
- [ ] Top 8 selected and sorted
- [ ] Selection written to HANA RFQINVITES table
- [ ] Structured JSON returned to orchestrator
- [ ] Human-readable summary shown